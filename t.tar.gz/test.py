print('__name__:', __name__)
def fn():
	print('this is test')

